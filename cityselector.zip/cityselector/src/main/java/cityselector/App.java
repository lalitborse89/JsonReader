/*Program that returns both largest city and 
* capital based on user input for state name or state abbreviation. 
*/ 
package cityselector;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class App {



	@SuppressWarnings("resource")
	public static void main(String[] args) throws FileNotFoundException, JSONException{
		// TODO Auto-generated method stub

		String jsonData = "";
		BufferedReader br = null;
		try {
			String line;
			br = new BufferedReader(new FileReader("jsonData"));
			while ((line = br.readLine()) != null) {
				jsonData += line + "\n";
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		JSONObject obj = new JSONObject(jsonData);



		JSONObject innerObj = obj.getJSONObject("RestResponse");


		JSONArray jA = innerObj.getJSONArray("result");



		JSONObject innermostObj = new JSONObject();

		Scanner scanner = new Scanner(System. in); 

		System.out.println("Enter the Name or the Abbrivation of STATE:");
		String input = scanner. nextLine();

		for(int i=0;i<jA.length();i++){

			innermostObj=(JSONObject) jA.get(i);
			
			String abbr= (String) innermostObj.get("abbr");
			String name= (String) innermostObj.get("name");
			
			
			if(input==abbr|| input==name || input.equals(abbr)||input.equals(name) ){
				System.out.println(abbr);
				System.out.println(name);
					
				if(innermostObj.has("capital"))
				System.out.println("Capital==>"+innermostObj.get("capital"));
				else
				System.out.println("Capital not found in file");
					
				
				if(innermostObj.has("largest_city"))
				System.out.println("Largest City ==>"+innermostObj.get("largest_city"));
				else
				System.out.println("Largest_city not found in file");
				
				
				break;
			
			}


		}

	

	}

}







